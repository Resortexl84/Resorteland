plugin.video.netflixbmc
=======================

This is a fork of the excellent Netflix plugin for xbmc/kodi by AddonScripterDE
https://code.google.com/p/addonscriptorde-beta-repo/

It has a number of fixes for changes in netflix site code and a few extra speed tweaks.

Please feel free to fix any problems found and submit pull reqests.

There are some dependencies for this plugin, all of which should be available on my repo.
See the forum thread for more details:
http://forum.kodi.tv/showthread.php?tid=211574
